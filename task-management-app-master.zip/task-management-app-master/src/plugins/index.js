import Vue from "vue"
import "./vee-validate"
import DeviceDetect from "./device-detect"
Vue.use(DeviceDetect)
