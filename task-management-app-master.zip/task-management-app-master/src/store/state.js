export default {
  isLoading: true,
  activeBoard: null,
  boards: []
}
