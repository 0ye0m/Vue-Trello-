module.exports = {
  printWidth: 120,
  tabWidth: 2,
  semi: false
}
