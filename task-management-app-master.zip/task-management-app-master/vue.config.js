module.exports = {
  productionSourceMap: false
}
